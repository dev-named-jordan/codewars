require './lib/text'

text = Text.new
mod_text = text.message_to_text('space.txt', 'pipe.txt', 'comma.txt')
